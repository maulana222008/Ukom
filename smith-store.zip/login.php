<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$tab = isset($_GET['tab']) ? $_GET['tab'] : 'login';
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = db_connect();
    $action = $_POST['action'] ?? '';

    if ($action === 'login') {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!$username || !$password) {
            $error = 'Username dan password wajib diisi.';
        } else {
            $u = db_escape($conn, $username);
            $cashier = db_fetch_one($conn, "SELECT * FROM cashiers WHERE username='$u' LIMIT 1");
            if ($cashier && verify_password($password, $cashier['password'])) {
                login_user($cashier);
                header('Location: ' . BASE_URL . '/index.php');
                exit;
            } else {
                $error = 'Username atau password salah.';
            }
        }
    } elseif ($action === 'register') {
        $tab = 'register';
        $username  = trim($_POST['reg_username'] ?? '');
        $email     = trim($_POST['reg_email'] ?? '');
        $password  = $_POST['reg_password'] ?? '';
        $confirm   = $_POST['reg_confirm'] ?? '';

        if (!$username || !$email || !$password) {
            $error = 'Semua field wajib diisi.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Email tidak valid.';
        } elseif (strlen($password) < 6) {
            $error = 'Password minimal 6 karakter.';
        } elseif ($password !== $confirm) {
            $error = 'Konfirmasi password tidak cocok.';
        } else {
            $u = db_escape($conn, $username);
            $e = db_escape($conn, $email);
            // Check duplicate
            $existing = db_fetch_one($conn, "SELECT id FROM cashiers WHERE username='$u' OR email='$e' LIMIT 1");
            if ($existing) {
                $error = 'Username atau email sudah digunakan.';
            } else {
                $hashed = hash_password($password);
                $h = db_escape($conn, $hashed);
                db_query($conn, "INSERT INTO cashiers (username, email, password, role) VALUES ('$u','$e','$h','cashier')");
                $success = 'Akun berhasil dibuat! Silakan login.';
                $tab = 'login';
            }
        }
        mysqli_close($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?= STORE_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="auth-page">
<div class="auth-card">
    <div class="auth-logo">
        <div class="logo-icon"><i class="fas fa-store"></i></div>
        <h1><?= STORE_NAME ?></h1>
        <p><i class="fas fa-map-marker-alt"></i> <?= STORE_LOCATION ?></p>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <div class="auth-tabs">
        <button class="auth-tab <?= $tab === 'login' ? 'active' : '' ?>" onclick="switchTab('login')">Login</button>
        <button class="auth-tab <?= $tab === 'register' ? 'active' : '' ?>" onclick="switchTab('register')">Daftar</button>
    </div>

    <!-- Login Form -->
    <div id="tabLogin" style="<?= $tab === 'login' ? '' : 'display:none' ?>">
        <form method="POST">
            <input type="hidden" name="action" value="login">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Username</label>
                <input type="text" name="username" class="form-control" placeholder="Masukkan username" required autofocus>
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Password</label>
                <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block" style="margin-top:8px">
                <i class="fas fa-sign-in-alt"></i> Masuk
            </button>
        </form>
    </div>

    <!-- Register Form -->
    <div id="tabRegister" style="<?= $tab === 'register' ? '' : 'display:none' ?>">
        <form method="POST">
            <input type="hidden" name="action" value="register">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Username</label>
                <input type="text" name="reg_username" class="form-control" placeholder="Username kasir">
            </div>
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email</label>
                <input type="email" name="reg_email" class="form-control" placeholder="Email kasir">
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Password</label>
                <input type="password" name="reg_password" class="form-control" placeholder="Min. 6 karakter">
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Konfirmasi Password</label>
                <input type="password" name="reg_confirm" class="form-control" placeholder="Ulangi password">
            </div>
            <button type="submit" class="btn btn-primary btn-block" style="margin-top:8px">
                <i class="fas fa-user-plus"></i> Daftar
            </button>
        </form>
    </div>
</div>
<script>
function switchTab(tab) {
    document.getElementById('tabLogin').style.display = tab === 'login' ? '' : 'none';
    document.getElementById('tabRegister').style.display = tab === 'register' ? '' : 'none';
    document.querySelectorAll('.auth-tab').forEach(function(t, i) {
        t.classList.toggle('active', (i === 0 && tab === 'login') || (i === 1 && tab === 'register'));
    });
}
</script>
</body>
</html>
