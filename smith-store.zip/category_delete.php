<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();

$id = intval($_GET['id'] ?? 0);
if ($id > 0) {
    $conn = db_connect();
    $in_use = db_fetch_one($conn, "SELECT COUNT(*) as cnt FROM products WHERE category_id=$id");
    if ($in_use['cnt'] > 0) {
        $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Kategori memiliki produk, tidak dapat dihapus.'];
    } else {
        db_query($conn, "DELETE FROM categories WHERE id=$id");
        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Kategori berhasil dihapus.'];
    }
    mysqli_close($conn);
}
header('Location: ' . BASE_URL . '/categories.php');
exit;
