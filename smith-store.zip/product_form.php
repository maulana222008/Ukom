<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();

$conn = db_connect();
$id = intval($_GET['id'] ?? 0);
$is_edit = $id > 0;
$page_title = $is_edit ? 'Edit Produk' : 'Tambah Produk';

$errors = [];
$product = [
    'name' => '', 'sku' => '', 'category_id' => '', 'berat' => '',
    'price' => '', 'discount' => 0, 'stock' => 0
];

if ($is_edit) {
    $p = db_fetch_one($conn, "SELECT * FROM products WHERE id=$id LIMIT 1");
    if (!$p) { header('Location: ' . BASE_URL . '/products.php'); exit; }
    $product = $p;
}

$categories = db_fetch_all($conn, "SELECT * FROM categories ORDER BY nama");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category_id = intval($_POST['category_id'] ?? 0);
    $berat = intval($_POST['berat'] ?? 0);
    $price = floatval(str_replace(',', '.', $_POST['price'] ?? 0));
    $discount = floatval($_POST['discount'] ?? 0);
    $stock = intval($_POST['stock'] ?? 0);
    $manual_sku = isset($_POST['manual_sku']) && $_POST['manual_sku'] === '1';

    // Validate
    if (!$name) $errors[] = 'Nama produk wajib diisi.';
    if (!$category_id) $errors[] = 'Kategori wajib dipilih.';
    if ($berat <= 0) $errors[] = 'Berat harus lebih dari 0.';
    if ($price <= 0) $errors[] = 'Harga harus lebih dari 0.';
    if ($discount < 0 || $discount > 100) $errors[] = 'Diskon harus antara 0-100%.';
    if ($stock < 0) $errors[] = 'Stok tidak boleh negatif.';

    // Auto-generate SKU
    $cat = null;
    if ($category_id) {
        $cat = db_fetch_one($conn, "SELECT * FROM categories WHERE id=$category_id LIMIT 1");
        if (!$cat) $errors[] = 'Kategori tidak valid.';
    }

    if (empty($errors) && $cat) {
        // SKU = ALIAS-NAMATANPASPASI-BERAT
        $name_part = strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', str_replace(' ', '', $name)));
        $sku = strtoupper($cat['alias']) . '-' . $name_part . '-' . $berat;

        // Check SKU uniqueness
        $esc_sku = db_escape($conn, $sku);
        $esc_name = db_escape($conn, $name);
        $esc_price = number_format($price, 2, '.', '');
        $esc_disc = number_format($discount, 2, '.', '');

        if ($is_edit) {
            $existing = db_fetch_one($conn, "SELECT id FROM products WHERE sku='$esc_sku' AND id!=$id LIMIT 1");
        } else {
            $existing = db_fetch_one($conn, "SELECT id FROM products WHERE sku='$esc_sku' LIMIT 1");
        }
        if ($existing) {
            $errors[] = 'SKU "' . htmlspecialchars($sku) . '" sudah digunakan oleh produk lain.';
        }

        if (empty($errors)) {
            if ($is_edit) {
                db_query($conn, "UPDATE products SET name='$esc_name', sku='$esc_sku', category_id=$category_id, berat=$berat, price=$esc_price, discount=$esc_disc, stock=$stock WHERE id=$id");
                $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Produk berhasil diupdate.'];
            } else {
                db_query($conn, "INSERT INTO products (name, sku, category_id, berat, price, discount, stock) VALUES ('$esc_name','$esc_sku',$category_id,$berat,$esc_price,$esc_disc,$stock)");
                $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Produk berhasil ditambahkan.'];
            }
            mysqli_close($conn);
            header('Location: ' . BASE_URL . '/products.php');
            exit;
        }
    }

    // Keep values for re-display
    $product = array_merge($product, [
        'name' => $name, 'category_id' => $category_id,
        'berat' => $berat, 'price' => $price,
        'discount' => $discount, 'stock' => $stock
    ]);
}

mysqli_close($conn);
include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
    <h1><i class="fas fa-<?= $is_edit ? 'edit' : 'plus-circle' ?>"></i> <?= $page_title ?></h1>
    <a href="products.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Kembali</a>
</div>

<?php if ($errors): ?>
<div class="alert alert-danger">
    <div><i class="fas fa-exclamation-triangle"></i> <strong>Terdapat kesalahan:</strong></div>
    <?php foreach ($errors as $e): ?>
    <div style="margin-top:4px">• <?= htmlspecialchars($e) ?></div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="card" style="max-width:680px">
    <div class="card-header">
        <h2><i class="fas fa-box"></i> <?= $is_edit ? 'Edit' : 'Data' ?> Produk</h2>
    </div>
    <div class="card-body">
        <form method="POST">
            <div class="form-row">
                <div class="form-group">
                    <label>Nama Produk *</label>
                    <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($product['name']) ?>" placeholder="Nama produk" required id="nameInput">
                </div>
                <div class="form-group">
                    <label>Kategori *</label>
                    <select name="category_id" class="form-control" required id="catSelect">
                        <option value="">Pilih Kategori</option>
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" data-alias="<?= htmlspecialchars($cat['alias']) ?>" <?= $product['category_id'] == $cat['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['nama']) ?> (<?= $cat['alias'] ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Berat (gram) *</label>
                    <input type="number" name="berat" class="form-control" value="<?= htmlspecialchars($product['berat']) ?>" placeholder="Berat dalam gram" min="1" required id="beratInput">
                </div>
                <div class="form-group">
                    <label>SKU (Auto-generate)</label>
                    <input type="text" id="skuPreview" class="form-control" value="<?= htmlspecialchars($product['sku'] ?? '') ?>" placeholder="SKU akan digenerate otomatis" readonly style="background:#f0f3fb;color:#1a2b4a;font-family:monospace;font-weight:700">
                    <div class="form-hint">Format: ALIAS-NAMA-BERAT (otomatis dari kategori, nama, dan berat)</div>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Harga (Rp) *</label>
                    <input type="number" name="price" class="form-control" value="<?= htmlspecialchars($product['price']) ?>" placeholder="Harga satuan" min="1" step="100" required>
                </div>
                <div class="form-group">
                    <label>Diskon (%)</label>
                    <input type="number" name="discount" class="form-control" value="<?= htmlspecialchars($product['discount']) ?>" placeholder="0" min="0" max="100" step="0.5">
                    <div class="form-hint">0 = tidak ada diskon</div>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Stok Awal</label>
                    <input type="number" name="stock" class="form-control" value="<?= htmlspecialchars($product['stock']) ?>" placeholder="0" min="0">
                </div>
            </div>

            <div style="display:flex;gap:10px;margin-top:8px">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?= $is_edit ? 'Update' : 'Simpan' ?> Produk</button>
                <a href="products.php" class="btn btn-secondary"><i class="fas fa-times"></i> Batal</a>
            </div>
        </form>
    </div>
</div>

<script>
function updateSKUPreview() {
    var name = document.getElementById('nameInput').value.trim();
    var catSel = document.getElementById('catSelect');
    var berat = document.getElementById('beratInput').value;
    var alias = catSel.options[catSel.selectedIndex] ? (catSel.options[catSel.selectedIndex].dataset.alias || '') : '';

    if (name && alias && berat) {
        var namePart = name.toUpperCase().replace(/[^A-Z0-9]/g, '');
        document.getElementById('skuPreview').value = alias.toUpperCase() + '-' + namePart + '-' + berat;
    } else {
        document.getElementById('skuPreview').value = '';
    }
}
document.getElementById('nameInput').addEventListener('input', updateSKUPreview);
document.getElementById('catSelect').addEventListener('change', updateSKUPreview);
document.getElementById('beratInput').addEventListener('input', updateSKUPreview);
updateSKUPreview();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
