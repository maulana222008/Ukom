<?php
function db_connect() {
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if (!$conn) {
        die(json_encode(['error' => 'Database connection failed: ' . mysqli_connect_error()]));
    }
    mysqli_set_charset($conn, 'utf8mb4');
    return $conn;
}

function db_escape($conn, $val) {
    return mysqli_real_escape_string($conn, $val);
}

function db_query($conn, $sql) {
    $result = mysqli_query($conn, $sql);
    if ($result === false) {
        error_log("DB Error: " . mysqli_error($conn) . " SQL: " . $sql);
    }
    return $result;
}

function db_fetch_all($conn, $sql) {
    $result = db_query($conn, $sql);
    $rows = [];
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
        mysqli_free_result($result);
    }
    return $rows;
}

function db_fetch_one($conn, $sql) {
    $result = db_query($conn, $sql);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        mysqli_free_result($result);
        return $row;
    }
    return null;
}

function db_insert_id($conn) {
    return mysqli_insert_id($conn);
}

function db_affected_rows($conn) {
    return mysqli_affected_rows($conn);
}
