<?php
// includes/header.php
$user = current_user();
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? htmlspecialchars($page_title) . ' - ' : '' ?><?= STORE_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout">
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="store-logo">
                <i class="fas fa-store"></i>
            </div>
            <div class="store-info">
                <span class="store-name"><?= STORE_NAME ?></span>
                <span class="store-loc"><i class="fas fa-map-marker-alt"></i> <?= STORE_LOCATION ?></span>
            </div>
        </div>
        <nav class="sidebar-nav">
            <ul>
                <li class="<?= $current_page === 'index' ? 'active' : '' ?>">
                    <a href="<?= BASE_URL ?>/index.php"><i class="fas fa-cash-register"></i><span>Kasir</span></a>
                </li>
                <li class="<?= $current_page === 'transactions' ? 'active' : '' ?>">
                    <a href="<?= BASE_URL ?>/transactions.php"><i class="fas fa-receipt"></i><span>Riwayat Transaksi</span></a>
                </li>
                <li class="<?= in_array($current_page, ['products','product_add','product_edit']) ? 'active' : '' ?>">
                    <a href="<?= BASE_URL ?>/products.php"><i class="fas fa-box"></i><span>Produk</span></a>
                </li>
                <li class="<?= in_array($current_page, ['categories','category_add','category_edit']) ? 'active' : '' ?>">
                    <a href="<?= BASE_URL ?>/categories.php"><i class="fas fa-tags"></i><span>Kategori</span></a>
                </li>
                <?php if ($user['role'] === 'admin'): ?>
                <li class="<?= in_array($current_page, ['cashiers','cashier_view','cashier_edit']) ? 'active' : '' ?>">
                    <a href="<?= BASE_URL ?>/cashiers.php"><i class="fas fa-users"></i><span>Daftar Kasir</span></a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar"><i class="fas fa-user-circle"></i></div>
                <div class="user-meta">
                    <span class="user-name"><?= htmlspecialchars($user['username']) ?></span>
                    <span class="user-role"><?= ucfirst($user['role']) ?></span>
                </div>
            </div>
            <div class="sidebar-footer-links">
                <a href="<?= BASE_URL ?>/profile.php" class="btn-icon" title="Profil"><i class="fas fa-user-cog"></i></a>
                <a href="<?= BASE_URL ?>/logout.php" class="btn-icon btn-danger-icon" title="Keluar"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>
    </aside>
    <!-- Main -->
    <div class="main-wrapper">
        <header class="topbar">
            <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <div class="topbar-title"><?= isset($page_title) ? htmlspecialchars($page_title) : STORE_NAME ?></div>
            <div class="topbar-right">
                <span class="topbar-date" id="topbarDate"></span>
            </div>
        </header>
        <main class="main-content">
            <?php if (isset($_SESSION['flash'])): ?>
            <div class="alert alert-<?= $_SESSION['flash']['type'] ?>" id="flashMsg">
                <i class="fas fa-<?= $_SESSION['flash']['type'] === 'success' ? 'check-circle' : 'exclamation-triangle' ?>"></i>
                <?= htmlspecialchars($_SESSION['flash']['msg']) ?>
                <button onclick="this.parentElement.remove()" class="alert-close">&times;</button>
            </div>
            <?php unset($_SESSION['flash']); endif; ?>
