<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();

$page_title = 'Kasir POS';

// Handle post-transaction success
$last_trx = null;
$cash_paid = 0;
$change = 0;
if (isset($_SESSION['last_trx'])) {
    $last_trx = $_SESSION['last_trx'];
    $cash_paid = $_SESSION['cash_paid'] ?? 0;
    $change = $_SESSION['change'] ?? 0;
    unset($_SESSION['last_trx'], $_SESSION['cash_paid'], $_SESSION['change']);
}

include __DIR__ . '/includes/header.php';
?>
<script>var BASE_URL = '<?= BASE_URL ?>';</script>

<?php if ($last_trx): ?>
<!-- Transaction Success Modal -->
<div class="modal-overlay active" id="successModal">
    <div class="modal" style="max-width:400px">
        <div class="modal-header" style="background:linear-gradient(135deg,#28a745,#218838)">
            <h3><i class="fas fa-check-circle"></i> Transaksi Berhasil!</h3>
            <button class="modal-close" onclick="closeModal('successModal')">&times;</button>
        </div>
        <div class="modal-body" style="text-align:center">
            <div style="font-size:3rem;color:#28a745;margin-bottom:14px"><i class="fas fa-receipt"></i></div>
            <div style="font-size:1.1rem;font-weight:700;color:#1a2b4a;margin-bottom:6px"><?= htmlspecialchars($last_trx['kode']) ?></div>
            <div style="color:#8a9ab8;font-size:0.85rem;margin-bottom:16px"><?= date('d M Y H:i', strtotime($last_trx['created_at'])) ?></div>
            <div class="summary-row" style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #e8edf5">
                <span>Total Belanja</span><span style="font-weight:700"><?= format_rupiah($last_trx['grand_total']) ?></span>
            </div>
            <div class="summary-row" style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #e8edf5">
                <span>Bayar</span><span style="font-weight:700"><?= format_rupiah($cash_paid) ?></span>
            </div>
            <div class="summary-row" style="display:flex;justify-content:space-between;padding:8px 0;font-size:1.1rem">
                <span>Kembalian</span><span style="font-weight:800;color:#28a745"><?= format_rupiah($change) ?></span>
            </div>
        </div>
        <div class="modal-footer" style="justify-content:center;gap:10px">
            <button onclick="printReceipt(<?= $last_trx['id'] ?>)" class="btn btn-secondary btn-sm"><i class="fas fa-print"></i> Cetak</button>
            <button onclick="downloadReceiptPDF(<?= $last_trx['id'] ?>)" class="btn btn-outline btn-sm"><i class="fas fa-file-pdf"></i> PDF</button>
            <button onclick="closeModal('successModal')" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Transaksi Baru</button>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="pos-layout">
    <!-- LEFT: Search + Cart -->
    <div class="pos-left">
        <!-- SKU Search -->
        <div class="card pos-search-area">
            <div class="card-header">
                <h2><i class="fas fa-barcode"></i> Input Produk via SKU</h2>
                <span style="font-size:0.75rem;opacity:0.75">Tekan Enter untuk cari</span>
            </div>
            <div class="card-body">
                <div class="search-sku-group">
                    <input type="text" id="skuInput" class="form-control" placeholder="Masukkan SKU produk (contoh: MNM-AQUABOTOL-600)" autocomplete="off" style="text-transform:uppercase">
                    <button onclick="searchSKU()" class="btn btn-primary"><i class="fas fa-search"></i> Cari</button>
                </div>
                <div id="productFound" class="product-found" style="display:none"></div>
                <div id="notFound" class="not-found-msg"><i class="fas fa-exclamation-circle"></i> <span></span></div>
                <div style="margin-top:8px;font-size:0.75rem;color:#8a9ab8"><i class="fas fa-keyboard"></i> Tekan Enter atau klik Cari — produk otomatis masuk keranjang</div>
            </div>
        </div>

        <!-- Cart -->
        <div class="card cart-area">
            <div class="card-header">
                <h2><i class="fas fa-shopping-cart"></i> Keranjang</h2>
                <button onclick="clearCart()" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Kosongkan</button>
            </div>
            <div class="cart-body">
                <div id="cartEmpty" class="cart-empty">
                    <i class="fas fa-shopping-basket"></i>
                    <p>Keranjang masih kosong</p>
                    <p style="font-size:0.8rem">Scan atau ketik SKU produk untuk menambahkan</p>
                </div>
                <table id="cartTable" class="cart-table" style="display:none">
                    <thead>
                        <tr>
                            <th>Produk</th>
                            <th>Harga</th>
                            <th>Qty</th>
                            <th>Subtotal</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="cartBody"></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- RIGHT: Summary + Payment -->
    <div class="pos-right">
        <div class="card" style="height:100%;display:flex;flex-direction:column">
            <div class="card-header">
                <h2><i class="fas fa-file-invoice-dollar"></i> Ringkasan & Bayar</h2>
            </div>

            <div class="pos-summary" style="flex:1">
                <div class="summary-row">
                    <span class="summary-label">Subtotal</span>
                    <span id="sumSubtotal">Rp 0</span>
                </div>
                <div class="summary-row">
                    <span class="summary-label">Diskon</span>
                    <span id="sumDiscount" style="color:#28a745">-Rp 0</span>
                </div>
                <div class="summary-row total">
                    <span><i class="fas fa-tag"></i> Grand Total</span>
                    <span id="sumTotal">Rp 0</span>
                </div>
            </div>

            <div class="payment-area">
                <div class="payment-label"><i class="fas fa-money-bill-wave"></i> Uang Diterima</div>
                <div class="cash-input-group">
                    <input type="text" id="cashInput" class="form-control" placeholder="0" oninput="formatCashInput(this)" style="font-size:1.1rem;font-weight:700">
                </div>
                <!-- Quick cash buttons -->
                <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px">
                    <?php foreach ([5000,10000,20000,50000,100000] as $nom): ?>
                    <button class="btn btn-secondary btn-sm" onclick="setCash(<?= $nom ?>)"><?= number_format($nom/1000) ?>rb</button>
                    <?php endforeach; ?>
                    <button class="btn btn-secondary btn-sm" onclick="setExact()">Pas</button>
                </div>
                <div class="change-display">
                    <span class="label">Kembalian</span>
                    <span id="changeAmount">Rp 0</span>
                </div>
                <button onclick="processPayment()" class="btn btn-success btn-block" style="font-size:1rem;padding:14px">
                    <i class="fas fa-check-circle"></i> Proses Pembayaran
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function setCash(amount) {
    var input = document.getElementById('cashInput');
    var currentRaw = input.value.replace(/[^0-9]/g,'');
    var current = parseInt(currentRaw) || 0;
    var newVal = current + amount;
    input.value = newVal.toLocaleString('id-ID');
    calcChange();
}
function setExact() {
    var totalEl = document.getElementById('sumTotal');
    if (!totalEl) return;
    var total = parseInt(totalEl.textContent.replace(/[^0-9]/g,'')) || 0;
    document.getElementById('cashInput').value = total.toLocaleString('id-ID');
    calcChange();
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
