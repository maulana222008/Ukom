<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_admin();

$id = intval($_GET['id'] ?? 0);
$user = current_user();

if ($id > 0 && $id != $user['id']) {
    $conn = db_connect();
    $trx_count = db_fetch_one($conn, "SELECT COUNT(*) as cnt FROM transactions WHERE cashier_id=$id");
    if ($trx_count['cnt'] > 0) {
        $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Kasir memiliki riwayat transaksi, tidak dapat dihapus.'];
    } else {
        db_query($conn, "DELETE FROM cashiers WHERE id=$id");
        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Kasir berhasil dihapus.'];
    }
    mysqli_close($conn);
}
header('Location: ' . BASE_URL . '/cashiers.php');
exit;
