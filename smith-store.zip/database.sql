CREATE DATABASE IF NOT EXISTS smith_store_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smith_store_db;

CREATE TABLE IF NOT EXISTS cashiers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','cashier') DEFAULT 'cashier',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    alias CHAR(3) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    sku VARCHAR(100) NOT NULL UNIQUE,
    category_id INT NOT NULL,
    berat INT NOT NULL COMMENT 'gram',
    price DECIMAL(12,2) NOT NULL,
    discount DECIMAL(5,2) DEFAULT 0 COMMENT 'percent',
    stock INT DEFAULT 0,
    sold INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(50) NOT NULL UNIQUE,
    cashier_id INT NOT NULL,
    products LONGTEXT NOT NULL COMMENT 'snapshot of items',
    grand_total DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cashier_id) REFERENCES cashiers(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- username = admin
-- password = admin123
INSERT INTO cashiers (username, email, password, role) VALUES
('admin', 'admin@admin.com', '$2y$10$1BBxdDE55zv5GUImeM2NNuTPNeUvqjny0UJSTG48yLqn9RmbxMTIy', 'admin');

-- Sample categories
INSERT INTO categories (nama, alias) VALUES
('Minuman', 'MNM'),
('Makanan', 'MKN'),
('Snack', 'SNK'),
('Kebersihan', 'KBR'),
('Rokok', 'ROK');

-- Sample products
INSERT INTO products (name, sku, category_id, berat, price, discount, stock, sold) VALUES
('Aqua Botol', 'MNM-AQUABOTOL-600', 1, 600, 4000, 0, 100, 50),
('Indomie Goreng', 'MKN-INDOMIEGORENG-85', 2, 85, 3500, 0, 200, 120),
('Chitato Original', 'SNK-CHITATOORIGINAL-68', 3, 68, 11000, 5, 80, 30),
('Sabun Lifebuoy', 'KBR-SABUNLIFEBUOY-110', 4, 110, 8500, 0, 60, 20),
('Sampoerna Mild', 'ROK-SAMPOERNAMILD-16', 5, 16, 28000, 0, 150, 200);
