<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();

$id = intval($_GET['id'] ?? 0);
$user = current_user();

// Only admin or own profile
if ($user['role'] !== 'admin' && $user['id'] != $id) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$conn = db_connect();
$cashier = db_fetch_one($conn, "SELECT * FROM cashiers WHERE id=$id LIMIT 1");
if (!$cashier) { mysqli_close($conn); header('Location: ' . BASE_URL . '/cashiers.php'); exit; }

$page_title = 'Edit Profil: ' . $cashier['username'];
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_username = trim($_POST['username'] ?? '');
    $new_email = trim($_POST['email'] ?? '');
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $new_role = $_POST['role'] ?? 'cashier';

    if (!$new_username) $errors[] = 'Username wajib diisi.';
    if (!$new_email || !filter_var($new_email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email tidak valid.';
    if ($new_password && strlen($new_password) < 6) $errors[] = 'Password baru minimal 6 karakter.';
    if ($new_password && $new_password !== $confirm_password) $errors[] = 'Konfirmasi password tidak cocok.';
    if ($user['role'] !== 'admin') $new_role = $cashier['role']; // non-admin can't change role

    if (empty($errors)) {
        $esc_u = db_escape($conn, $new_username);
        $esc_e = db_escape($conn, $new_email);
        $esc_r = db_escape($conn, $new_role);

        // Check duplicate
        $dup = db_fetch_one($conn, "SELECT id FROM cashiers WHERE (username='$esc_u' OR email='$esc_e') AND id!=$id LIMIT 1");
        if ($dup) {
            $errors[] = 'Username atau email sudah digunakan.';
        } else {
            if ($new_password) {
                $hashed = hash_password($new_password);
                $esc_h = db_escape($conn, $hashed);
                db_query($conn, "UPDATE cashiers SET username='$esc_u', email='$esc_e', role='$esc_r', password='$esc_h' WHERE id=$id");
            } else {
                db_query($conn, "UPDATE cashiers SET username='$esc_u', email='$esc_e', role='$esc_r' WHERE id=$id");
            }

            // Update session if editing own profile
            if ($user['id'] == $id) {
                $_SESSION['username'] = $new_username;
                $_SESSION['email'] = $new_email;
                $_SESSION['role'] = $new_role;
            }

            $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Profil berhasil diupdate.'];
            mysqli_close($conn);
            header('Location: ' . BASE_URL . '/cashier_view.php?id=' . $id);
            exit;
        }
    }
}

mysqli_close($conn);
include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
    <h1><i class="fas fa-user-edit"></i> Edit Profil</h1>
    <a href="cashier_view.php?id=<?= $id ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Kembali ke Profil</a>
</div>

<div class="card" style="max-width:540px">
    <div class="card-header">
        <h2><i class="fas fa-user-cog"></i> Edit Data Kasir: <?= htmlspecialchars($cashier['username']) ?></h2>
    </div>
    <div class="card-body">
        <?php if ($errors): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $e): ?><div>• <?= htmlspecialchars($e) ?></div><?php endforeach; ?>
        </div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Username</label>
                <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($_POST['username'] ?? $cashier['username']) ?>" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email</label>
                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($_POST['email'] ?? $cashier['email']) ?>" required>
            </div>
            <?php if ($user['role'] === 'admin'): ?>
            <div class="form-group">
                <label><i class="fas fa-shield-alt"></i> Role</label>
                <select name="role" class="form-control">
                    <option value="cashier" <?= $cashier['role'] === 'cashier' ? 'selected' : '' ?>>Kasir</option>
                    <option value="admin" <?= $cashier['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                </select>
            </div>
            <?php endif; ?>
            <hr style="margin:18px 0;border-color:#e8edf5">
            <div style="font-size:0.85rem;color:#8a9ab8;margin-bottom:12px"><i class="fas fa-info-circle"></i> Kosongkan password jika tidak ingin mengubah password</div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Password Baru</label>
                <input type="password" name="new_password" class="form-control" placeholder="Min. 6 karakter">
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Konfirmasi Password</label>
                <input type="password" name="confirm_password" class="form-control" placeholder="Ulangi password baru">
            </div>
            <div style="display:flex;gap:8px;margin-top:8px">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Perubahan</button>
                <a href="cashier_view.php?id=<?= $id ?>" class="btn btn-secondary"><i class="fas fa-times"></i> Batal</a>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
