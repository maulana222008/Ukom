<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();

$id = intval($_GET['id'] ?? 0);
$user = current_user();

// Only admin or own profile
if ($user['role'] !== 'admin' && $user['id'] != $id) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$conn = db_connect();
$cashier = db_fetch_one($conn, "SELECT * FROM cashiers WHERE id=$id LIMIT 1");
if (!$cashier) { mysqli_close($conn); header('Location: ' . BASE_URL . '/cashiers.php'); exit; }

$page_title = 'Profil Kasir: ' . $cashier['username'];

$stats = db_fetch_one($conn, "SELECT COUNT(*) as cnt, SUM(grand_total) as total FROM transactions WHERE cashier_id=$id");
$recent_trx = db_fetch_all($conn, "SELECT * FROM transactions WHERE cashier_id=$id ORDER BY created_at DESC LIMIT 5");
mysqli_close($conn);

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
    <h1><i class="fas fa-user"></i> Profil Kasir</h1>
    <div style="display:flex;gap:8px">
        <?php if ($user['role'] === 'admin'): ?>
        <a href="cashiers.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Kembali</a>
        <?php endif; ?>
        <a href="cashier_edit.php?id=<?= $id ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> Edit Profil</a>
    </div>
</div>

<div style="display:grid;grid-template-columns:320px 1fr;gap:20px;align-items:start" class="profile-layout">
    <div class="card profile-card" style="min-width:0">
        <div class="profile-header">
            <div class="profile-avatar"><?= strtoupper(substr($cashier['username'],0,1)) ?></div>
            <div class="profile-name"><?= htmlspecialchars($cashier['username']) ?></div>
            <div class="profile-role">
                <span class="badge <?= $cashier['role'] === 'admin' ? 'badge-danger' : 'badge-info' ?>">
                    <?= ucfirst($cashier['role']) ?>
                </span>
            </div>
        </div>
        <div class="profile-info">
            <div class="info-row">
                <span class="info-label">Username</span>
                <span class="info-value" style="word-break:break-all"><?= htmlspecialchars($cashier['username']) ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Email</span>
                <span class="info-value" style="word-break:break-all"><?= htmlspecialchars($cashier['email']) ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Role</span>
                <span class="info-value"><?= ucfirst($cashier['role']) ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Bergabung</span>
                <span class="info-value"><?= date('d M Y H:i', strtotime($cashier['created_at'])) ?></span>
            </div>
        </div>
    </div>

    <div style="min-width:0">
        <div class="stats-grid" style="grid-template-columns:repeat(2,1fr);margin-bottom:16px">
            <div class="stat-card">
                <div class="stat-icon blue"><i class="fas fa-receipt"></i></div>
                <div><div class="stat-value"><?= number_format($stats['cnt'] ?? 0) ?></div><div class="stat-label">Total Transaksi</div></div>
            </div>
            <div class="stat-card" style="border-color:#28a745">
                <div class="stat-icon green"><i class="fas fa-money-bill-wave"></i></div>
                <div><div class="stat-value" style="font-size:0.9rem;word-break:break-all"><?= format_rupiah($stats['total'] ?? 0) ?></div><div class="stat-label">Total Penjualan</div></div>
            </div>
        </div>

        <div class="card" style="min-width:0">
            <div class="card-header"><h2><i class="fas fa-history"></i> Transaksi Terbaru</h2></div>
            <div class="card-body" style="padding:0;overflow-x:auto">
                <table style="min-width:360px">
                    <thead>
                        <tr><th>Kode</th><th>Grand Total</th><th>Tanggal</th></tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recent_trx)): ?>
                        <tr><td colspan="3" class="text-center text-muted" style="padding:20px">Belum ada transaksi.</td></tr>
                        <?php else: ?>
                        <?php foreach ($recent_trx as $t): ?>
                        <tr>
                            <td><span class="badge badge-info" style="font-family:monospace;font-size:0.75rem"><?= htmlspecialchars($t['kode']) ?></span></td>
                            <td style="font-weight:700"><?= format_rupiah($t['grand_total']) ?></td>
                            <td style="font-size:0.82rem;white-space:nowrap"><?= date('d M Y H:i', strtotime($t['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
@media (max-width:800px) {
    .profile-layout { grid-template-columns: 1fr !important; }
    .profile-layout > div { min-width: 0; }
}
</style>
<?php include __DIR__ . '/includes/footer.php'; ?>
