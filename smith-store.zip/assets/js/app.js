// Smith Store POS - Main JS

// ===== SIDEBAR TOGGLE =====
document.addEventListener('DOMContentLoaded', function() {
    var toggle = document.getElementById('sidebarToggle');
    var sidebar = document.getElementById('sidebar');
    if (toggle && sidebar) {
        toggle.addEventListener('click', function(e) {
            e.stopPropagation();
            sidebar.classList.toggle('open');
        });
    }

    // Close sidebar on outside click (mobile)
    document.addEventListener('click', function(e) {
        if (!sidebar) return;
        if (window.innerWidth <= 900 && sidebar.classList.contains('open') &&
            !sidebar.contains(e.target)) {
            sidebar.classList.remove('open');
        }
    });

    // Topbar date
    var dateEl = document.getElementById('topbarDate');
    if (dateEl) {
        var now = new Date();
        var opts = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        dateEl.textContent = now.toLocaleDateString('id-ID', opts);
    }

    // Auto dismiss alerts
    var flash = document.getElementById('flashMsg');
    if (flash) {
        setTimeout(function() {
            flash.style.opacity = '0';
            flash.style.transition = 'opacity 0.5s';
            setTimeout(function() { flash.remove(); }, 500);
        }, 4000);
    }
});

// ===== POS KASIR =====
var cart = {};

function searchSKU() {
    var sku = document.getElementById('skuInput').value.trim().toUpperCase();
    if (!sku) return;
    var notFound = document.getElementById('notFound');
    var foundCard = document.getElementById('productFound');

    fetch(BASE_URL + '/api/product_by_sku.php?sku=' + encodeURIComponent(sku))
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.error) {
                foundCard.classList.remove('show');
                notFound.classList.add('show');
                notFound.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + data.error;
            } else {
                notFound.classList.remove('show');
                foundCard.classList.remove('show');
                // Auto add to cart immediately
                addToCart(data);
                showToast('<i class="fas fa-check-circle"></i> ' + data.name + ' ditambahkan ke keranjang', 'success');
                document.getElementById('skuInput').value = '';
            }
        })
        .catch(function() {
            notFound.classList.add('show');
            notFound.innerHTML = '<i class="fas fa-exclamation-circle"></i> Error mencari produk.';
            foundCard.classList.remove('show');
        });
}

function addFoundToCart() {
    var foundCard = document.getElementById('productFound');
    if (!foundCard.dataset.product) return;
    var product = JSON.parse(foundCard.dataset.product);
    addToCart(product);
    document.getElementById('skuInput').value = '';
    foundCard.classList.remove('show');
    document.getElementById('skuInput').focus();
}

function addToCart(product) {
    if (cart[product.id]) {
        if (cart[product.id].qty >= product.stock) {
            showToast('Stok tidak cukup!', 'danger');
            return;
        }
        cart[product.id].qty++;
    } else {
        if (product.stock < 1) {
            showToast('Stok habis!', 'danger');
            return;
        }
        cart[product.id] = {
            id: product.id,
            name: product.name,
            sku: product.sku,
            price: product.price,
            discount: product.discount,
            final_price: product.final_price,
            stock: product.stock,
            qty: 1
        };
    }
    renderCart();
}

function removeFromCart(id) {
    delete cart[id];
    renderCart();
}

function updateQty(id, val) {
    if (!cart[id]) return;
    var qty = parseInt(val);
    if (isNaN(qty) || qty < 1) qty = 1;
    if (qty > cart[id].stock) qty = cart[id].stock;
    cart[id].qty = qty;
    renderCart();
}

function changeQty(id, delta) {
    if (!cart[id]) return;
    var newQty = cart[id].qty + delta;
    if (newQty < 1) { removeFromCart(id); return; }
    if (newQty > cart[id].stock) { showToast('Stok tidak cukup!', 'danger'); return; }
    cart[id].qty = newQty;
    renderCart();
}

function renderCart() {
    var tbody = document.getElementById('cartBody');
    var emptyMsg = document.getElementById('cartEmpty');
    var cartTable = document.getElementById('cartTable');
    var ids = Object.keys(cart);

    if (ids.length === 0) {
        if (tbody) tbody.innerHTML = '';
        if (emptyMsg) emptyMsg.style.display = 'block';
        if (cartTable) cartTable.style.display = 'none';
        updateSummary();
        return;
    }
    if (emptyMsg) emptyMsg.style.display = 'none';
    if (cartTable) cartTable.style.display = 'table';
    if (!tbody) return;

    var html = '';
    ids.forEach(function(id) {
        var item = cart[id];
        var subtotal = item.final_price * item.qty;
        html += '<tr>' +
            '<td><div style="font-weight:600;font-size:0.85rem">' + escHtml(item.name) + '</div>' +
            '<div style="font-size:0.75rem;color:#8a9ab8">' + escHtml(item.sku) + (item.discount > 0 ? ' <span class="badge badge-warning">-'+item.discount+'%</span>' : '') + '</div></td>' +
            '<td>' + formatRupiah(item.final_price) + '</td>' +
            '<td><div class="qty-control">' +
            '<button class="qty-btn" onclick="changeQty(' + id + ',-1)">-</button>' +
            '<input type="number" class="qty-input" value="' + item.qty + '" min="1" max="' + item.stock + '" onchange="updateQty(' + id + ',this.value)">' +
            '<button class="qty-btn" onclick="changeQty(' + id + ',1)">+</button>' +
            '</div></td>' +
            '<td>' + formatRupiah(subtotal) + '</td>' +
            '<td><button class="remove-btn" onclick="removeFromCart(' + id + ')"><i class="fas fa-trash"></i></button></td>' +
            '</tr>';
    });
    tbody.innerHTML = html;
    updateSummary();
}

function updateSummary() {
    var subtotal = 0, totalDiscount = 0;
    Object.values(cart).forEach(function(item) {
        var originalSubtotal = item.price * item.qty;
        var discountedSubtotal = item.final_price * item.qty;
        subtotal += originalSubtotal;
        totalDiscount += (originalSubtotal - discountedSubtotal);
    });
    var grand = subtotal - totalDiscount;

    el('sumSubtotal') && (el('sumSubtotal').textContent = formatRupiah(subtotal));
    el('sumDiscount') && (el('sumDiscount').textContent = '-' + formatRupiah(totalDiscount));
    el('sumTotal') && (el('sumTotal').textContent = formatRupiah(grand));

    // Update change
    calcChange();
}

function calcChange() {
    var totalEl = el('sumTotal');
    if (!totalEl) return;
    var totalText = totalEl.textContent.replace(/[^0-9]/g, '');
    var grand = parseInt(totalText) || 0;
    var cashEl = el('cashInput');
    var cash = cashEl ? (parseInt(cashEl.value.replace(/[^0-9]/g, '')) || 0) : 0;
    var change = cash - grand;
    var changeEl = el('changeAmount');
    if (changeEl) {
        changeEl.textContent = change >= 0 ? formatRupiah(change) : 'Kurang ' + formatRupiah(-change);
        changeEl.style.color = change >= 0 ? '#4ee87a' : '#ff6b7a';
    }
}

function processPayment() {
    var ids = Object.keys(cart);
    if (ids.length === 0) { showToast('Keranjang kosong!', 'danger'); return; }

    var totalEl = el('sumTotal');
    var totalText = totalEl ? totalEl.textContent.replace(/[^0-9]/g, '') : '0';
    var grand = parseInt(totalText) || 0;
    var cashEl = el('cashInput');
    var cash = cashEl ? (parseInt(cashEl.value.replace(/[^0-9]/g, '')) || 0) : 0;

    if (cash < grand) { showToast('Uang tunai kurang!', 'danger'); return; }

    var items = Object.values(cart).map(function(item) {
        return {
            id: item.id, name: item.name, sku: item.sku,
            price: item.price, discount: item.discount,
            final_price: item.final_price, qty: item.qty,
            subtotal: item.final_price * item.qty
        };
    });

    var form = document.createElement('form');
    form.method = 'POST';
    form.action = BASE_URL + '/process_transaction.php';
    var inp = document.createElement('input');
    inp.type = 'hidden'; inp.name = 'cart_data';
    inp.value = JSON.stringify(items);
    form.appendChild(inp);
    var inp2 = document.createElement('input');
    inp2.type = 'hidden'; inp2.name = 'grand_total';
    inp2.value = grand;
    form.appendChild(inp2);
    var inp3 = document.createElement('input');
    inp3.type = 'hidden'; inp3.name = 'cash_paid';
    inp3.value = cash;
    form.appendChild(inp3);
    document.body.appendChild(form);
    form.submit();
}

function clearCart() {
    if (Object.keys(cart).length === 0) return;
    if (confirm('Hapus semua item dari keranjang?')) {
        cart = {};
        renderCart();
    }
}

// ===== CASH INPUT FORMATTING =====
function formatCashInput(input) {
    var raw = input.value.replace(/[^0-9]/g, '');
    input.value = raw ? parseInt(raw).toLocaleString('id-ID') : '';
    calcChange();
}

// ===== RECEIPT / PRINT =====
function printReceipt(trxId) {
    var w = window.open('', 'receipt', 'width=380,height=600');
    fetch(BASE_URL + '/api/receipt.php?id=' + trxId)
        .then(function(r) { return r.text(); })
        .then(function(html) {
            w.document.write(html);
            w.document.close();
            w.onload = function() { w.print(); };
        });
}

function downloadReceiptPDF(trxId) {
    window.location.href = BASE_URL + '/api/receipt_pdf.php?id=' + trxId;
}

// ===== MODAL HELPERS =====
function openModal(id) {
    var m = document.getElementById(id);
    if (m) m.classList.add('active');
}
function closeModal(id) {
    var m = document.getElementById(id);
    if (m) m.classList.remove('active');
}

// Close modal on overlay click
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active');
    }
});

// ===== CONFIRM DELETE =====
function confirmDelete(url, msg) {
    if (confirm(msg || 'Yakin ingin menghapus?')) {
        window.location.href = url;
    }
}

// ===== UTILS =====
function el(id) { return document.getElementById(id); }
function escHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function formatRupiah(n) {
    return 'Rp ' + parseInt(n).toLocaleString('id-ID');
}
function showToast(msg, type) {
    var toast = document.createElement('div');
    toast.className = 'alert alert-' + (type || 'success');
    toast.style.cssText = 'position:fixed;bottom:20px;right:20px;z-index:9999;min-width:260px;box-shadow:0 4px 20px rgba(0,0,0,0.2)';
    toast.innerHTML = '<i class="fas fa-' + (type === 'danger' ? 'exclamation-circle' : 'check-circle') + '"></i> ' + msg;
    document.body.appendChild(toast);
    setTimeout(function() { toast.style.opacity = '0'; toast.style.transition = 'opacity 0.4s'; setTimeout(function() { toast.remove(); }, 400); }, 3000);
}

// ===== SKU INPUT ENTER =====
document.addEventListener('keydown', function(e) {
    var skuInput = el('skuInput');
    if (skuInput && e.target === skuInput && e.key === 'Enter') {
        e.preventDefault();
        searchSKU();
    }
});

// BASE_URL injected by PHP
