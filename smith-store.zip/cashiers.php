<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_admin();

$page_title = 'Daftar Kasir';
$conn = db_connect();
$search = trim($_GET['q'] ?? '');

$where = '1=1';
if ($search) { $s = db_escape($conn, $search); $where .= " AND (username LIKE '%$s%' OR email LIKE '%$s%')"; }

$cashiers = db_fetch_all($conn, "SELECT c.*, (SELECT COUNT(*) FROM transactions t WHERE t.cashier_id=c.id) as trx_count FROM cashiers c WHERE $where ORDER BY c.created_at DESC");
mysqli_close($conn);

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
    <h1><i class="fas fa-users"></i> Daftar Kasir</h1>
</div>

<div class="card">
    <div class="card-header"><h2><i class="fas fa-users"></i> Semua Kasir (<?= count($cashiers) ?>)</h2></div>
    <div class="card-body">
        <form method="GET" class="search-filter-bar">
            <input type="text" name="q" class="form-control" placeholder="Cari username/email..." value="<?= htmlspecialchars($search) ?>" style="max-width:260px">
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Cari</button>
            <a href="cashiers.php" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i> Reset</a>
        </form>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Jumlah Transaksi</th>
                        <th>Bergabung</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($cashiers)): ?>
                    <tr><td colspan="7" class="text-center text-muted" style="padding:30px">Tidak ada kasir.</td></tr>
                    <?php else: ?>
                    <?php foreach ($cashiers as $i => $c): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td>
                            <div style="display:flex;align-items:center;gap:8px">
                                <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#3a6bc4,#1a2b4a);display:flex;align-items:center;justify-content:center;color:white;font-weight:700;font-size:0.9rem;flex-shrink:0">
                                    <?= strtoupper(substr($c['username'],0,1)) ?>
                                </div>
                                <span style="font-weight:600"><?= htmlspecialchars($c['username']) ?></span>
                            </div>
                        </td>
                        <td><?= htmlspecialchars($c['email']) ?></td>
                        <td><?php
                            $role_class = $c['role'] === 'admin' ? 'badge-danger' : 'badge-info';
                            echo '<span class="badge ' . $role_class . '">' . ucfirst($c['role']) . '</span>';
                        ?></td>
                        <td><span class="badge badge-secondary"><?= number_format($c['trx_count']) ?></span></td>
                        <td style="font-size:0.82rem"><?= date('d M Y', strtotime($c['created_at'])) ?></td>
                        <td>
                            <div class="actions-cell">
                                <a href="cashier_view.php?id=<?= $c['id'] ?>" class="btn btn-secondary btn-sm" title="Lihat"><i class="fas fa-eye"></i></a>
                                <a href="cashier_edit.php?id=<?= $c['id'] ?>" class="btn btn-warning btn-sm" title="Edit"><i class="fas fa-edit"></i></a>
                                <?php if ($c['id'] != current_user()['id']): ?>
                                <button onclick="confirmDelete('cashier_delete.php?id=<?= $c['id'] ?>','Hapus kasir <?= htmlspecialchars(addslashes($c['username'])) ?>?')" class="btn btn-danger btn-sm" title="Hapus"><i class="fas fa-trash"></i></button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
