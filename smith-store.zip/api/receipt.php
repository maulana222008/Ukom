<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) { http_response_code(403); exit; }

$id = intval($_GET['id'] ?? 0);
$conn = db_connect();
$trx = db_fetch_one($conn, "SELECT t.*, c.username FROM transactions t LEFT JOIN cashiers c ON t.cashier_id=c.id WHERE t.id=$id LIMIT 1");
mysqli_close($conn);

if (!$trx) { http_response_code(404); echo 'Not found'; exit; }

// Access check
$user = current_user();
if ($user['role'] !== 'admin' && $user['id'] != $trx['cashier_id']) { http_response_code(403); exit; }

$products = json_decode($trx['products'], true);
$date = date('d/m/Y H:i', strtotime($trx['created_at']));

ob_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Struk - <?= $trx['kode'] ?></title>
<style>
* { margin:0;padding:0;box-sizing:border-box; }
body { font-family:'Courier New',monospace; font-size:12px; width:300px; margin:0 auto; padding:10px; background:#fff; }
.center { text-align:center; }
.bold { font-weight:bold; }
.divider { border:none; border-top:1px dashed #000; margin:6px 0; }
.row { display:flex; justify-content:space-between; margin:2px 0; }
.item-name { font-weight:bold; }
.item-detail { font-size:11px; color:#333; margin-left:8px; }
.total { font-size:14px; font-weight:bold; }
.footer { text-align:center; margin-top:8px; font-size:11px; }
</style>
</head>
<body>
<div class="center bold" style="font-size:14px"><?= STORE_NAME ?></div>
<div class="center" style="font-size:11px"><?= STORE_LOCATION ?></div>
<hr class="divider">
<div class="row"><span>Tanggal</span><span><?= $date ?></span></div>
<div class="row"><span>Kasir</span><span><?= htmlspecialchars($trx['username'] ?? '-') ?></span></div>
<div class="row"><span>Kode</span><span><?= htmlspecialchars($trx['kode']) ?></span></div>
<hr class="divider">
<?php foreach ($products as $item):
    $disc_text = $item['discount'] > 0 ? ' (-' . $item['discount'] . '%)' : '';
?>
<div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
<div class="row item-detail">
    <span><?= $item['qty'] ?> x Rp <?= number_format($item['final_price'], 0, ',', '.') ?><?= $disc_text ?></span>
    <span>Rp <?= number_format($item['subtotal'], 0, ',', '.') ?></span>
</div>
<?php endforeach; ?>
<hr class="divider">
<div class="row total">
    <span>GRAND TOTAL</span>
    <span>Rp <?= number_format($trx['grand_total'], 0, ',', '.') ?></span>
</div>
<hr class="divider">
<div class="footer">Terima kasih telah berbelanja di<br><?= STORE_NAME ?>!</div>
<script>window.print();</script>
</body>
</html>
<?php
echo ob_get_clean();
