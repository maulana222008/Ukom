<?php
// Smith Store Configuration
define('STORE_NAME', 'Smith Store');
define('STORE_LOCATION', 'Paris, Prancis');

// Helper: read env var from all possible sources.
// In Apache+Docker, $_SERVER is most reliable because Apache
// exposes SetEnv/PassEnv there. $_ENV and getenv() may be empty
// depending on php.ini variables_order and Apache config.
function _env($key, $default = '') {
    if (isset($_SERVER[$key]) && $_SERVER[$key] !== '') return $_SERVER[$key];
    if (isset($_ENV[$key])    && $_ENV[$key]    !== '') return $_ENV[$key];
    $v = getenv($key);
    if ($v !== false && $v !== '') return $v;
    return $default;
}

define('DB_HOST', _env('DB_HOST', 'localhost'));
define('DB_NAME', _env('DB_NAME', 'smith_store_db'));
define('DB_USER', _env('DB_USER', 'root'));
define('DB_PASS', _env('DB_PASS', ''));

// Base URL
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
define('BASE_URL', $protocol . '://' . $host);

// Session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
