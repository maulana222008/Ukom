<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();

$page_title = 'Manajemen Produk';
$conn = db_connect();

// Search & filter
$search = trim($_GET['q'] ?? '');
$cat_filter = intval($_GET['cat'] ?? 0);
$per_page = 15;
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * $per_page;

$where = '1=1';
if ($search) { $s = db_escape($conn, $search); $where .= " AND (p.name LIKE '%$s%' OR p.sku LIKE '%$s%')"; }
if ($cat_filter) $where .= " AND p.category_id=$cat_filter";

$count = db_fetch_one($conn, "SELECT COUNT(*) as cnt FROM products p WHERE $where");
$total = $count['cnt'] ?? 0;
$total_pages = max(1, ceil($total / $per_page));

$products = db_fetch_all($conn, "SELECT p.*, c.nama as cat_name, c.alias as cat_alias FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE $where ORDER BY p.created_at DESC LIMIT $per_page OFFSET $offset");
$categories = db_fetch_all($conn, "SELECT * FROM categories ORDER BY nama");
mysqli_close($conn);

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
    <h1><i class="fas fa-box"></i> Produk</h1>
    <a href="product_form.php" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah Produk</a>
</div>

<div class="card">
    <div class="card-header"><h2><i class="fas fa-list"></i> Daftar Produk (<?= number_format($total) ?>)</h2></div>
    <div class="card-body">
        <form method="GET" class="search-filter-bar">
            <input type="text" name="q" class="form-control" placeholder="Cari nama/SKU..." value="<?= htmlspecialchars($search) ?>" style="max-width:220px">
            <select name="cat" class="form-control" style="max-width:180px">
                <option value="">Semua Kategori</option>
                <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['id'] ?>" <?= $cat_filter == $cat['id'] ? 'selected' : '' ?>><?= htmlspecialchars($cat['nama']) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Cari</button>
            <a href="products.php" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i> Reset</a>
        </form>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>SKU</th>
                        <th>Nama Produk</th>
                        <th>Kategori</th>
                        <th>Berat</th>
                        <th>Harga</th>
                        <th>Diskon</th>
                        <th>Harga Final</th>
                        <th>Stok</th>
                        <th>Terjual</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($products)): ?>
                    <tr><td colspan="11" class="text-center text-muted" style="padding:30px">Tidak ada produk.</td></tr>
                    <?php else: ?>
                    <?php foreach ($products as $i => $p):
                        $final = $p['price'] * (1 - $p['discount']/100);
                    ?>
                    <tr>
                        <td><?= $offset + $i + 1 ?></td>
                        <td><code style="font-size:0.78rem;background:#f0f3fb;padding:3px 6px;border-radius:4px"><?= htmlspecialchars($p['sku']) ?></code></td>
                        <td style="font-weight:600"><?= htmlspecialchars($p['name']) ?></td>
                        <td><span class="badge badge-info"><?= htmlspecialchars($p['cat_alias'] ?? '') ?> - <?= htmlspecialchars($p['cat_name'] ?? '-') ?></span></td>
                        <td><?= number_format($p['berat']) ?> g</td>
                        <td><?= format_rupiah($p['price']) ?></td>
                        <td><?= $p['discount'] > 0 ? '<span class="badge badge-warning">' . $p['discount'] . '%</span>' : '-' ?></td>
                        <td style="font-weight:700;color:#1a2b4a"><?= format_rupiah($final) ?></td>
                        <td><?php
                            $stok_class = $p['stock'] <= 0 ? 'badge-danger' : ($p['stock'] <= 10 ? 'badge-warning' : 'badge-success');
                            echo '<span class="badge ' . $stok_class . '">' . number_format($p['stock']) . '</span>';
                        ?></td>
                        <td><?= number_format($p['sold']) ?></td>
                        <td>
                            <div class="actions-cell">
                                <a href="product_form.php?id=<?= $p['id'] ?>" class="btn btn-warning btn-sm" title="Edit"><i class="fas fa-edit"></i></a>
                                <button onclick="confirmDelete('product_delete.php?id=<?= $p['id'] ?>','Hapus produk <?= htmlspecialchars(addslashes($p['name'])) ?>?')" class="btn btn-danger btn-sm" title="Hapus"><i class="fas fa-trash"></i></button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?><a href="?page=<?= $page-1 ?>&q=<?= urlencode($search) ?>&cat=<?= $cat_filter ?>" class="page-btn"><i class="fas fa-chevron-left"></i></a><?php endif; ?>
            <?php for ($p2 = max(1,$page-2); $p2 <= min($total_pages,$page+2); $p2++): ?>
            <a href="?page=<?= $p2 ?>&q=<?= urlencode($search) ?>&cat=<?= $cat_filter ?>" class="page-btn <?= $p2 === $page ? 'active' : '' ?>"><?= $p2 ?></a>
            <?php endfor; ?>
            <?php if ($page < $total_pages): ?><a href="?page=<?= $page+1 ?>&q=<?= urlencode($search) ?>&cat=<?= $cat_filter ?>" class="page-btn"><i class="fas fa-chevron-right"></i></a><?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
