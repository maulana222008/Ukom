<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if (!is_logged_in()) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$sku = strtoupper(trim($_GET['sku'] ?? ''));
if (!$sku) {
    echo json_encode(['error' => 'SKU tidak boleh kosong']);
    exit;
}

$conn = db_connect();
$esc = db_escape($conn, $sku);
$product = db_fetch_one($conn, "SELECT p.*, c.nama as cat_name, c.alias as cat_alias FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.sku='$esc' LIMIT 1");
mysqli_close($conn);

if (!$product) {
    echo json_encode(['error' => 'Produk dengan SKU "' . htmlspecialchars($sku) . '" tidak ditemukan.']);
    exit;
}

$final_price = $product['price'] * (1 - $product['discount'] / 100);
$product['final_price'] = round($final_price, 2);
$product['price'] = floatval($product['price']);
$product['discount'] = floatval($product['discount']);

echo json_encode($product);
