<?php
function is_logged_in() {
    return isset($_SESSION['cashier_id']);
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function require_admin() {
    require_login();
    if ($_SESSION['role'] !== 'admin') {
        header('Location: ' . BASE_URL . '/index.php?err=forbidden');
        exit;
    }
}

function current_user() {
    return [
        'id'       => $_SESSION['cashier_id'] ?? null,
        'username' => $_SESSION['username'] ?? '',
        'role'     => $_SESSION['role'] ?? '',
        'email'    => $_SESSION['email'] ?? '',
    ];
}

function login_user($cashier) {
    $_SESSION['cashier_id'] = $cashier['id'];
    $_SESSION['username']   = $cashier['username'];
    $_SESSION['role']       = $cashier['role'];
    $_SESSION['email']      = $cashier['email'];
}

function logout_user() {
    session_destroy();
}

function hash_password($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

function verify_password($password, $hash) {
    return password_verify($password, $hash);
}

function generate_trx_code() {
    return 'TRX-' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8)) . '-' . date('Ymd');
}

function format_rupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}
