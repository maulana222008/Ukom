<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_login();
$user = current_user();
header('Location: ' . BASE_URL . '/cashier_view.php?id=' . $user['id']);
exit;
