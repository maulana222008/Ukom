<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();

$id = intval($_GET['id'] ?? 0);
if ($id > 0) {
    $conn = db_connect();
    // Check if in transactions
    $in_use = db_fetch_one($conn, "SELECT COUNT(*) as cnt FROM transactions WHERE JSON_SEARCH(products, 'one', '$id', NULL, '\$[*].id') IS NOT NULL");
    if ($in_use && $in_use['cnt'] > 0) {
        $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Produk tidak dapat dihapus karena digunakan dalam transaksi.'];
    } else {
        db_query($conn, "DELETE FROM products WHERE id=$id");
        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Produk berhasil dihapus.'];
    }
    mysqli_close($conn);
}
header('Location: ' . BASE_URL . '/products.php');
exit;
