<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$cart_json = $_POST['cart_data'] ?? '[]';
$grand_total = intval($_POST['grand_total'] ?? 0);
$cash_paid = intval(str_replace('.', '', $_POST['cash_paid'] ?? 0));

$items = json_decode($cart_json, true);
if (!$items || count($items) === 0) {
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Keranjang kosong.'];
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$conn = db_connect();
$user = current_user();

// Generate unique transaction code
do {
    $kode = generate_trx_code();
    $esc_kode = db_escape($conn, $kode);
    $existing = db_fetch_one($conn, "SELECT id FROM transactions WHERE kode='$esc_kode' LIMIT 1");
} while ($existing);

// Validate stock and compute total
$actual_total = 0;
foreach ($items as &$item) {
    $pid = intval($item['id']);
    $qty = intval($item['qty']);
    $product = db_fetch_one($conn, "SELECT * FROM products WHERE id=$pid LIMIT 1");
    if (!$product) {
        $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Produk tidak ditemukan.'];
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
    if ($product['stock'] < $qty) {
        $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Stok ' . $product['name'] . ' tidak cukup.'];
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
    $fp = $product['price'] * (1 - $product['discount']/100);
    $item['name'] = $product['name'];
    $item['price'] = $product['price'];
    $item['discount'] = $product['discount'];
    $item['final_price'] = $fp;
    $item['subtotal'] = $fp * $qty;
    $actual_total += $item['subtotal'];
}
unset($item);

// Insert transaction - use hex literal to safely insert JSON containing quotes/backslashes
$json_str = json_encode($items, JSON_UNESCAPED_UNICODE);
$json_hex  = bin2hex($json_str);
$cashier_id = $user['id'];
$gt = number_format($actual_total, 2, '.', '');

$sql = "INSERT INTO transactions (kode, cashier_id, products, grand_total) VALUES ('$esc_kode', $cashier_id, UNHEX('$json_hex'), $gt)";
$result = db_query($conn, $sql);
if (!$result) {
    error_log("Transaction insert failed: " . mysqli_error($conn));
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Gagal menyimpan transaksi: ' . mysqli_error($conn)];
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}
$trx_id = db_insert_id($conn);

// Update stock and sold
foreach ($items as $item) {
    $pid = intval($item['id']);
    $qty = intval($item['qty']);
    db_query($conn, "UPDATE products SET stock=stock-$qty, sold=sold+$qty WHERE id=$pid");
}

// Fetch the transaction
$trx = db_fetch_one($conn, "SELECT * FROM transactions WHERE id=$trx_id LIMIT 1");
$change = $cash_paid - $actual_total;

mysqli_close($conn);

$_SESSION['last_trx'] = $trx;
$_SESSION['cash_paid'] = $cash_paid;
$_SESSION['change'] = $change;
$_SESSION['flash'] = ['type' => 'success', 'msg' => 'Transaksi ' . $kode . ' berhasil!'];

header('Location: ' . BASE_URL . '/index.php');
exit;
