<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();

$page_title = 'Manajemen Kategori';
$conn = db_connect();

$errors = [];
$edit_cat = null;
$edit_id = intval($_GET['edit'] ?? 0);

if ($edit_id > 0) {
    $edit_cat = db_fetch_one($conn, "SELECT * FROM categories WHERE id=$edit_id LIMIT 1");
}

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $nama = trim($_POST['nama'] ?? '');
    $alias = strtoupper(trim($_POST['alias'] ?? ''));

    if (!$nama) $errors[] = 'Nama kategori wajib diisi.';
    if (!$alias) $errors[] = 'Alias wajib diisi.';
    elseif (strlen($alias) !== 3) $errors[] = 'Alias harus tepat 3 karakter.';
    elseif (!ctype_alnum($alias)) $errors[] = 'Alias hanya boleh huruf dan angka.';

    if (empty($errors)) {
        $esc_nama = db_escape($conn, $nama);
        $esc_alias = db_escape($conn, $alias);

        if ($action === 'edit' && isset($_POST['edit_id'])) {
            $eid = intval($_POST['edit_id']);
            $dup = db_fetch_one($conn, "SELECT id FROM categories WHERE (alias='$esc_alias' OR nama='$esc_nama') AND id!=$eid LIMIT 1");
            if ($dup) {
                $errors[] = 'Nama atau alias sudah digunakan.';
            } else {
                db_query($conn, "UPDATE categories SET nama='$esc_nama', alias='$esc_alias' WHERE id=$eid");
                $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Kategori berhasil diupdate.'];
                mysqli_close($conn);
                header('Location: ' . BASE_URL . '/categories.php');
                exit;
            }
        } else {
            $dup = db_fetch_one($conn, "SELECT id FROM categories WHERE alias='$esc_alias' OR nama='$esc_nama' LIMIT 1");
            if ($dup) {
                $errors[] = 'Nama atau alias sudah digunakan.';
            } else {
                db_query($conn, "INSERT INTO categories (nama, alias) VALUES ('$esc_nama','$esc_alias')");
                $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Kategori berhasil ditambahkan.'];
                mysqli_close($conn);
                header('Location: ' . BASE_URL . '/categories.php');
                exit;
            }
        }
    }
}

$categories = db_fetch_all($conn, "SELECT c.*, COUNT(p.id) as product_count FROM categories c LEFT JOIN products p ON p.category_id=c.id GROUP BY c.id ORDER BY c.nama");
mysqli_close($conn);

include __DIR__ . '/includes/header.php';
?>
<div class="page-header">
    <h1><i class="fas fa-tags"></i> Kategori</h1>
</div>

<div style="display:grid;grid-template-columns:350px 1fr;gap:20px;align-items:start" class="cat-layout">
    <!-- Form -->
    <div class="card">
        <div class="card-header">
            <h2><i class="fas fa-<?= $edit_cat ? 'edit' : 'plus' ?>"></i> <?= $edit_cat ? 'Edit' : 'Tambah' ?> Kategori</h2>
            <?php if ($edit_cat): ?>
            <a href="categories.php" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i></a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <?php if ($errors): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $e): ?><div>• <?= htmlspecialchars($e) ?></div><?php endforeach; ?>
            </div>
            <?php endif; ?>
            <form method="POST">
                <input type="hidden" name="action" value="<?= $edit_cat ? 'edit' : 'add' ?>">
                <?php if ($edit_cat): ?>
                <input type="hidden" name="edit_id" value="<?= $edit_cat['id'] ?>">
                <?php endif; ?>
                <div class="form-group">
                    <label>Nama Kategori *</label>
                    <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($edit_cat['nama'] ?? $_POST['nama'] ?? '') ?>" placeholder="Contoh: Minuman" required>
                </div>
                <div class="form-group">
                    <label>Alias (3 karakter) *</label>
                    <input type="text" name="alias" class="form-control" value="<?= htmlspecialchars($edit_cat['alias'] ?? $_POST['alias'] ?? '') ?>" placeholder="MNM" maxlength="3" style="text-transform:uppercase;font-family:monospace;font-size:1.1rem;font-weight:700;letter-spacing:2px" required>
                    <div class="form-hint">Alias digunakan sebagai prefix SKU produk. Contoh: MNM untuk Minuman</div>
                </div>
                <div style="display:flex;gap:8px">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <?= $edit_cat ? 'Update' : 'Simpan' ?></button>
                    <?php if ($edit_cat): ?><a href="categories.php" class="btn btn-secondary"><i class="fas fa-times"></i> Batal</a><?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- List -->
    <div class="card">
        <div class="card-header"><h2><i class="fas fa-list"></i> Daftar Kategori</h2></div>
        <div class="card-body" style="padding:0">
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama Kategori</th>
                            <th>Alias</th>
                            <th>Jumlah Produk</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($categories)): ?>
                        <tr><td colspan="5" class="text-center text-muted" style="padding:30px">Belum ada kategori.</td></tr>
                        <?php else: ?>
                        <?php foreach ($categories as $i => $cat): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td style="font-weight:600"><?= htmlspecialchars($cat['nama']) ?></td>
                            <td><code style="background:#e8f0fe;color:#1a2b4a;padding:3px 8px;border-radius:4px;font-weight:700;font-size:0.9rem"><?= htmlspecialchars($cat['alias']) ?></code></td>
                            <td><span class="badge badge-info"><?= number_format($cat['product_count']) ?> produk</span></td>
                            <td>
                                <div class="actions-cell">
                                    <a href="categories.php?edit=<?= $cat['id'] ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></a>
                                    <?php if ($cat['product_count'] == 0): ?>
                                    <button onclick="confirmDelete('category_delete.php?id=<?= $cat['id'] ?>','Hapus kategori <?= htmlspecialchars(addslashes($cat['nama'])) ?>?')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                                    <?php else: ?>
                                    <button class="btn btn-danger btn-sm" disabled title="Ada produk di kategori ini"><i class="fas fa-trash"></i></button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
@media (max-width:800px) { .cat-layout { grid-template-columns:1fr!important; } }
</style>
<?php include __DIR__ . '/includes/footer.php'; ?>
