<?php
// Receipt PDF - generates receipt as downloadable HTML with print dialog / PDF generation
// Since we're on native PHP without libraries, we output receipt HTML optimized for print/save as PDF
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) { http_response_code(403); exit; }

$id = intval($_GET['id'] ?? 0);
$conn = db_connect();
$trx = db_fetch_one($conn, "SELECT t.*, c.username FROM transactions t LEFT JOIN cashiers c ON t.cashier_id=c.id WHERE t.id=$id LIMIT 1");
mysqli_close($conn);

if (!$trx) { http_response_code(404); exit; }

$user = current_user();
if ($user['role'] !== 'admin' && $user['id'] != $trx['cashier_id']) { http_response_code(403); exit; }

$products = json_decode($trx['products'], true);
$date = date('d/m/Y H:i', strtotime($trx['created_at']));
$filename = 'Struk_' . $trx['kode'] . '.html';

header('Content-Type: text/html; charset=utf-8');
header('Content-Disposition: inline; filename="' . $filename . '"');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Struk - <?= htmlspecialchars($trx['kode']) ?></title>
<style>
@page { size: 80mm auto; margin: 4mm; }
@media print {
    html, body { width: 80mm; }
    .no-print { display: none !important; }
    body { -webkit-print-color-adjust: exact; }
}
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family: 'Courier New', Courier, monospace; font-size: 12px; width: 280px; max-width: 100%; margin: 0 auto; padding: 12px; background: #fff; color: #000; }
.center { text-align: center; }
.bold { font-weight: bold; }
.divider { border: none; border-top: 1px dashed #555; margin: 6px 0; }
.row { display: flex; justify-content: space-between; margin: 3px 0; }
.title { font-size: 15px; font-weight: bold; letter-spacing: 1px; }
.subtitle { font-size: 10px; color: #333; margin: 2px 0; }
.item-name { font-weight: bold; font-size: 12px; margin-top: 4px; }
.item-sub { font-size: 11px; padding-left: 6px; display: flex; justify-content: space-between; }
.grand { font-size: 14px; font-weight: bold; display: flex; justify-content: space-between; }
.footer { text-align: center; font-size: 10px; margin-top: 6px; color: #444; }
.print-btn-area { text-align: center; padding: 16px; }
.print-btn { padding: 10px 26px; background: #1a2b4a; color: white; border: none; border-radius: 7px; font-size: 14px; cursor: pointer; margin: 4px; }
.save-btn { padding: 10px 26px; background: #28a745; color: white; border: none; border-radius: 7px; font-size: 14px; cursor: pointer; margin: 4px; }
</style>
</head>
<body>

<div class="no-print print-btn-area">
    <button class="print-btn" onclick="window.print()">🖨️ Cetak / Simpan PDF</button>
    <p style="font-size:11px;color:#666;margin-top:8px">Gunakan Ctrl+P atau tombol di atas, pilih "Save as PDF" untuk menyimpan</p>
</div>

<div class="center title"><?= STORE_NAME ?></div>
<div class="center subtitle"><?= STORE_LOCATION ?></div>
<div class="center subtitle">================================</div>

<div class="row"><span>Tanggal</span><span><?= $date ?></span></div>
<div class="row"><span>Kasir</span><span><?= htmlspecialchars($trx['username'] ?? '-') ?></span></div>
<div class="row"><span>No. Transaksi</span><span style="font-size:10px"><?= htmlspecialchars($trx['kode']) ?></span></div>

<hr class="divider">
<div style="font-weight:bold;margin-bottom:4px">ITEM</div>

<?php
$subtotal_all = 0;
$discount_all = 0;
foreach ($products as $item):
    $orig = $item['price'] * $item['qty'];
    $final = $item['final_price'] * $item['qty'];
    $disc = $orig - $final;
    $subtotal_all += $orig;
    $discount_all += $disc;
?>
<div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
<div class="item-sub">
    <span><?= $item['qty'] ?> x Rp<?= number_format($item['final_price'], 0, ',', '.') ?><?= $item['discount'] > 0 ? ' (-'.$item['discount'].'%)' : '' ?></span>
    <span>Rp<?= number_format($final, 0, ',', '.') ?></span>
</div>
<?php endforeach; ?>

<hr class="divider">
<?php if ($discount_all > 0): ?>
<div class="row"><span>Subtotal</span><span>Rp<?= number_format($subtotal_all, 0, ',', '.') ?></span></div>
<div class="row"><span>Diskon</span><span>-Rp<?= number_format($discount_all, 0, ',', '.') ?></span></div>
<hr class="divider">
<?php endif; ?>
<div class="grand"><span>GRAND TOTAL</span><span>Rp<?= number_format($trx['grand_total'], 0, ',', '.') ?></span></div>
<hr class="divider">
<div class="center footer">
    ~ Terima kasih telah berbelanja ~<br>
    <?= STORE_NAME ?> - <?= STORE_LOCATION ?><br>
    <?= date('d M Y', strtotime($trx['created_at'])) ?>
</div>

<script>
// Auto trigger print on load for PDF
setTimeout(function() {
    if (window.location.search.indexOf('auto=1') !== -1) {
        window.print();
    }
}, 500);
</script>
</body>
</html>
