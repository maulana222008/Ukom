<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();

$page_title = 'Riwayat Transaksi';
$conn = db_connect();
$user = current_user();

// Pagination
$per_page = 15;
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * $per_page;

// Search
$search = trim($_GET['q'] ?? '');
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

$where = '1=1';
if ($search) {
    $s = db_escape($conn, $search);
    $where .= " AND (t.kode LIKE '%$s%' OR c.username LIKE '%$s%')";
}
if ($date_from) {
    $df = db_escape($conn, $date_from);
    $where .= " AND DATE(t.created_at) >= '$df'";
}
if ($date_to) {
    $dt = db_escape($conn, $date_to);
    $where .= " AND DATE(t.created_at) <= '$dt'";
}
// Non-admin only sees own
if ($user['role'] !== 'admin') {
    $uid = intval($user['id']);
    $where .= " AND t.cashier_id=$uid";
}

$count_res = db_fetch_one($conn, "SELECT COUNT(*) as cnt FROM transactions t LEFT JOIN cashiers c ON t.cashier_id=c.id WHERE $where");
$total = $count_res['cnt'] ?? 0;
$total_pages = max(1, ceil($total / $per_page));

$transactions = db_fetch_all($conn, "SELECT t.*, c.username as cashier_name FROM transactions t LEFT JOIN cashiers c ON t.cashier_id=c.id WHERE $where ORDER BY t.created_at DESC LIMIT $per_page OFFSET $offset");

// Summary stats
$stats = db_fetch_one($conn, "SELECT COUNT(*) as cnt, SUM(grand_total) as total FROM transactions t WHERE $where");

mysqli_close($conn);

include __DIR__ . '/includes/header.php';
?>
<script>var BASE_URL = '<?= BASE_URL ?>';</script>
<div class="page-header">
    <h1><i class="fas fa-receipt"></i> Riwayat Transaksi</h1>
</div>

<div class="stats-grid" style="margin-bottom:18px">
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-receipt"></i></div>
        <div><div class="stat-value"><?= number_format($stats['cnt'] ?? 0) ?></div><div class="stat-label">Total Transaksi</div></div>
    </div>
    <div class="stat-card" style="border-color:#28a745">
        <div class="stat-icon green"><i class="fas fa-money-bill-wave"></i></div>
        <div><div class="stat-value" style="font-size:1rem"><?= format_rupiah($stats['total'] ?? 0) ?></div><div class="stat-label">Total Pendapatan</div></div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-list"></i> Daftar Transaksi</h2>
    </div>
    <div class="card-body">
        <!-- Filters -->
        <form method="GET" class="search-filter-bar">
            <input type="text" name="q" class="form-control" placeholder="Cari kode / kasir..." value="<?= htmlspecialchars($search) ?>" style="max-width:220px">
            <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($date_from) ?>" style="max-width:160px">
            <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($date_to) ?>" style="max-width:160px">
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Filter</button>
            <a href="transactions.php" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i> Reset</a>
        </form>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Kode Transaksi</th>
                        <th>Kasir</th>
                        <th>Item</th>
                        <th>Grand Total</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($transactions)): ?>
                    <tr><td colspan="7" class="text-center text-muted" style="padding:30px">Tidak ada transaksi ditemukan.</td></tr>
                    <?php else: ?>
                    <?php foreach ($transactions as $i => $trx):
                        $products = json_decode($trx['products'], true);
                        $item_count = count($products);
                    ?>
                    <tr>
                        <td><?= $offset + $i + 1 ?></td>
                        <td><span class="badge badge-info" style="font-family:monospace;font-size:0.8rem"><?= htmlspecialchars($trx['kode']) ?></span></td>
                        <td><i class="fas fa-user" style="color:#8a9ab8"></i> <?= htmlspecialchars($trx['cashier_name'] ?? '-') ?></td>
                        <td><span class="badge badge-secondary"><?= $item_count ?> item</span></td>
                        <td style="font-weight:700;color:#1a2b4a"><?= format_rupiah($trx['grand_total']) ?></td>
                        <td style="font-size:0.83rem"><?= date('d M Y H:i', strtotime($trx['created_at'])) ?></td>
                        <td>
                            <div class="actions-cell">
                                <button onclick="openTrxDetail(<?= htmlspecialchars(json_encode($trx)) ?>)" class="btn btn-secondary btn-sm" title="Detail"><i class="fas fa-eye"></i></button>
                                <button onclick="printReceipt(<?= $trx['id'] ?>)" class="btn btn-outline btn-sm" title="Cetak"><i class="fas fa-print"></i></button>
                                <button onclick="downloadReceiptPDF(<?= $trx['id'] ?>)" class="btn btn-secondary btn-sm" title="PDF"><i class="fas fa-file-pdf"></i></button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
            <a href="?page=<?= $page-1 ?>&q=<?= urlencode($search) ?>&date_from=<?= urlencode($date_from) ?>&date_to=<?= urlencode($date_to) ?>" class="page-btn"><i class="fas fa-chevron-left"></i></a>
            <?php endif; ?>
            <?php for ($p = max(1,$page-2); $p <= min($total_pages,$page+2); $p++): ?>
            <a href="?page=<?= $p ?>&q=<?= urlencode($search) ?>&date_from=<?= urlencode($date_from) ?>&date_to=<?= urlencode($date_to) ?>" class="page-btn <?= $p === $page ? 'active' : '' ?>"><?= $p ?></a>
            <?php endfor; ?>
            <?php if ($page < $total_pages): ?>
            <a href="?page=<?= $page+1 ?>&q=<?= urlencode($search) ?>&date_from=<?= urlencode($date_from) ?>&date_to=<?= urlencode($date_to) ?>" class="page-btn"><i class="fas fa-chevron-right"></i></a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Transaction Detail Modal -->
<div class="modal-overlay" id="trxDetailModal">
    <div class="modal" style="max-width:560px">
        <div class="modal-header">
            <h3><i class="fas fa-receipt"></i> Detail Transaksi</h3>
            <button class="modal-close" onclick="closeModal('trxDetailModal')">&times;</button>
        </div>
        <div class="modal-body" id="trxDetailBody" style="max-height:70vh;overflow-y:auto"></div>
        <div class="modal-footer">
            <button onclick="printReceiptFromModal()" class="btn btn-secondary btn-sm"><i class="fas fa-print"></i> Cetak</button>
            <button onclick="downloadReceiptPDFFromModal()" class="btn btn-outline btn-sm"><i class="fas fa-file-pdf"></i> PDF</button>
            <button onclick="closeModal('trxDetailModal')" class="btn btn-primary btn-sm">Tutup</button>
        </div>
    </div>
</div>

<script>
var currentTrxId = null;
function openTrxDetail(trx) {
    currentTrxId = trx.id;
    var products = JSON.parse(trx.products || '[]');
    var html = '<div style="font-size:0.82rem;color:#8a9ab8;margin-bottom:4px">' + (trx.created_at || '') + '</div>';
    html += '<div style="font-size:1.1rem;font-weight:700;color:#1a2b4a;margin-bottom:12px;font-family:monospace">' + trx.kode + '</div>';
    html += '<table style="width:100%;font-size:0.85rem;margin-bottom:12px"><thead><tr style="background:#1a2b4a;color:white"><th style="padding:8px">Produk</th><th style="padding:8px">SKU</th><th style="padding:8px">Harga</th><th style="padding:8px">Qty</th><th style="padding:8px">Subtotal</th></tr></thead><tbody>';
    products.forEach(function(item) {
        html += '<tr style="border-bottom:1px solid #e8edf5"><td style="padding:8px">' + item.name + '</td><td style="padding:8px;font-family:monospace;font-size:0.78rem">' + item.sku + '</td><td style="padding:8px">Rp ' + parseInt(item.final_price).toLocaleString('id-ID') + (item.discount > 0 ? ' <span class="badge badge-warning">-'+item.discount+'%</span>' : '') + '</td><td style="padding:8px;text-align:center">' + item.qty + '</td><td style="padding:8px;font-weight:700">Rp ' + parseInt(item.subtotal).toLocaleString('id-ID') + '</td></tr>';
    });
    html += '</tbody></table>';
    html += '<div style="text-align:right;font-size:1.05rem;font-weight:800;color:#1a2b4a;padding:10px 0;border-top:2px solid #e8edf5">Grand Total: Rp ' + parseInt(trx.grand_total).toLocaleString('id-ID') + '</div>';
    document.getElementById('trxDetailBody').innerHTML = html;
    openModal('trxDetailModal');
}
function printReceiptFromModal() { if (currentTrxId) printReceipt(currentTrxId); }
function downloadReceiptPDFFromModal() { if (currentTrxId) downloadReceiptPDF(currentTrxId); }
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
