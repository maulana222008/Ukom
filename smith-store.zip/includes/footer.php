        </main>
    </div><!-- end main-wrapper -->
</div><!-- end layout -->
<script src="<?= BASE_URL ?>/assets/js/app.js"></script>
</body>
</html>
